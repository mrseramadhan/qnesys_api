<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use app\Format_API;

class Hotel_Controller extends Controller
{
    /**
     * Handle the incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function __construct()
    {
      
    }

    public function __invoke(Request $request)
    {
        //
    }
}
